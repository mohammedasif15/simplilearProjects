import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { getToken, getUser } from '../Utils/Common';
import Axios from 'axios';

class BrowseAllItems extends Component {


    constructor(props) {
        super(props);

        this.state = {
            items: [],
            responseError: ""
        }
    }

    getFoodItems = () => {
        Axios.get("http://localhost:3001/foodItems")
            .then((res) => {
                const eventsList = res.data;
                this.setState({ items: eventsList });
            })
            .catch(err => {
                console.log("There is some error : ", err);
            })
    }


    deleteNote(id) {
        Axios.delete('http://localhost:3001/foodItem/' + id, {
            headers: {
                "x-auth-token": getToken()
            }
        })
            .then((result) => {
                alert("Item deleted successfully !");
                this.getFoodItems();
            })
            .catch(err => console.log("There is some error : " + err));
    }



    componentDidMount = () => {
        this.getFoodItems();
    }


    render() {
        return (
            <div className="container">
                <h3>{this.state.items.length > 0 ? "Here You Go !!" : "Welcome To The Kitchen."}</h3>
           

<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://i.pinimg.com/474x/ae/0c/97/ae0c978cbb0eb5641e8071f38e36182a.jpg" width="300px" height="300px" float="right"></img>
      <h1>Black Forest</h1>
        <p class="card-text">Price : 99.00$</p>
        <a href="#" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://origin.club/media/catalog/category/Dals_Pulses_C.jpg" width="300px" height="300px" float="right"></img>
      <h1>Dal and Pulses</h1>
        <p class="card-text">Price : 08.35$</p>
        <a href="/itemAdd" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
</div>
<br></br>

<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://qph.fs.quoracdn.net/main-qimg-94e5019215289d3c8767027c23f2d229" width="300px" height="300px" float="right"></img>
      <h1>Ghee and oil</h1>
        <p class="card-text">Price : 50.00$</p>
        <a href="#" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://www.jiomart.com/images/category/14/thumb/0-14.png" width="300px" height="300px" float="right"></img>
      <h1>Ataa and Flours</h1>
        <p class="card-text">Price : 30.00$.</p>
        <a href="/itemAdd" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://www.cookingclassy.com/wp-content/uploads/2021/01/garam-masala-7.jpg" width="300px" height="300px" float="right"></img>
      <h1>Masala and speices</h1>
        <p class="card-text">Price : 60.00$</p>
        <a href="#" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcAP12w5O_AWh202vAQIhgVi3m1peTXIhsgtfzeEbf_zyyqiKE6SOcvv4042KAAqlz-mw&usqp=CAU" width="300px" height="300px" float="right"></img>
      <h1>soft Drinks</h1>
        <p class="card-text">Price : 10.00$.</p>
        <a href="/itemAdd" class="btn btn-primary">Buy</a>
      </div>
    </div>
  </div>
</div>



               <br></br>
                {getUser() !== null ? <Link to="/itemAdd" className="btn btn-info" >Add New Item</Link> : <Link to="/itemAdd" className="btn btn-secondary disabled">Login to add new item</Link>}
                <br/><br />
                <div className="row">
                    {this.state.items.map((eventValue, index) => {
                        return (
                            <div key={index} className="col-sm-3 mt-3">
                                <div key={index} className="card rounded border border-success">
                                    <div key={index} className="card-body">
                                        <h3 className="card-title text-danger title">{eventValue.name}</h3>
                                        <p className="card-text">Category: {eventValue.category}</p>
                                        <p className="card-title">Brand: {eventValue.brand}</p>
                                        <p className="card-title">Price: {eventValue.price}</p>
                                        <Link to={'/itemDetail/' + eventValue._id} className="btn btn-primary btn-sm">View and Buy</Link>
                                        {getToken() !== null ? <button onClick={this.deleteNote.bind(this, eventValue._id)} style={{ margin: 2 }} className="btn btn-danger btn-sm">Delete</button> : ""}
                                        {getToken() !== null ? <Link to={'/itemEdit/' + eventValue._id} style={{ margin: 2 }} className="btn btn-info btn-sm">Edit</Link> : ""}
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div >
        )
    }

}

export default BrowseAllItems;